var total = 50;//number fo particles
var plist = [];//like arraylist

function setup() {
  createCanvas(400, 400);//size of the window
  
  for( let i=0; i < total; i++){//setup movement
      plist.push(new particle());
    
  }
  
}

function draw() {
  background(255);//background color
  
  for(let i=0; i < plist.length;i++){//drw movement
    plist[i].display();
  }
}


class particle{
  
  
  constructor(){//set the variables and make the boundries fo each point
    this.x0 = random(0,width/2);
    this.y0 = random(0,height/2);
    
    this.x1 = random(width/2, width);
    this.y1 = random(0,height/2);
    
    this.x2 = random(width/2, width);
    this.y2 = random(height/2,height);
    
    this.x3 = random(0,width/2);
    this.y3 = random(height/2,height);
    
  
  
  }
display(){//set the moving area,color,size,position,stepsize and boundries of the four points

  //point0
  strokeWeight(5);//width of the stroke
  stroke(136,115,135);//color and transfer
  point(this.x0,this.y0);// inital position
  
   this.x0 += random(-5,5);
   this.y0 += random(-5,5);

  if(this.x0 > width/2 || this.x0 < 0|| this.y0 > height/2 || this.y0 < 0){
   this.x0 = random(0, width/2);//if so, make it back to screen
   this.y0 = random(0,height/2);//if so make it back
}
                  
  //point1
  strokeWeight(5);//width of the stroke
  stroke(102,50,96);//color and transfer
  point(this.x1,this.y1);// inital position
  
   this.x1 += random(-5,5);
   this.y1 += random(-5,5);

  if(this.x1 > width || this.x1 < width/2 ||  this.y0 < height/2 || this.y0 > height){
   this.x1 = random(width/2, width);//if so, make it back to screen
   this.y1 = random(0,height/2);//if so make it back
}
  
   //point2
  strokeWeight(5);//width of the stroke
  stroke(141,99,157);//color and transfer
  point(this.x2,this.y2);// inital position
  
   this.x2 += random(-5,5);
   this.y2 += random(-5,5);

  if(this.x1 > width || this.x1 < width/2 || this.y2 > height || this.y2 < height/2){
   this.x2 = random(width/2, width);//if so, make it back to screen
   this.y2 = random(height/2,height);//if so make it back
}
                  
  //point3
  strokeWeight(5);//width of the stroke
  stroke(185,149,184);//color and transfer
  point(this.x3,this.y3);// inital position
  
   this.x3 += random(-5,5);
   this.y3 += random(-5,5);

  if(this.x0 > width/2 || this.x0 < 0 || this.y2 > height || this.y2 < height/2){
   this.x3 = random(0, width/2);//if so, make it back to screen
   this.y3 = random(height/2,height);//if so make it back
}
}

}  